import pandas as pd
import numpy as np
import logging
import datetime
from typing import Optional, Tuple, List, Dict, Any
from sktime.performance_metrics.forecasting import mean_absolute_percentage_error, mean_squared_percentage_error, mean_absolute_scaled_error, mean_squared_scaled_error

# Logger setup
logger = logging.getLogger(__name__)

WEEKDAY_ORDER = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
MONTH_ORDER = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]


def get_peak_row(group: pd.DataFrame) -> pd.Series:
    """Get the peak row from a group based on maximum 'Actual' or 'Forecast' value."""
    if not group['Actual'].isna().all():
        return group.loc[group['Actual'].idxmax()]
    else:
        return group.loc[group['Forecast'].idxmax()]

    
def extract_week_data(df_combined: pd.DataFrame, current_year: int) -> tuple:
    """
    Extract week-related data from the DataFrame and limit dates up to the maximum date of the current year.
    Returns the modified DataFrame, minimum date of current year, and maximum week start date.
    """
    try:
        max_date_current_year = df_combined[df_combined['Year'] == current_year]['Date'].max()
        min_date_current_year = df_combined[df_combined['Year'] == current_year]['Date'].min()

        # Filter dataframe to include only dates up to the maximum date of the current year
        df_combined = df_combined[df_combined['Date'] <= max_date_current_year]
        df_combined['Week Number'] = df_combined['Date'].dt.isocalendar().week  # Week number extraction
        df_combined['Week Start'] = df_combined['Date'].dt.to_period('W').apply(lambda r: r.start_time)  # Week start date extraction

        # Limit the data to the maximum week start of the current year
        max_week_start = df_combined[df_combined['Year'] == current_year]['Week Start'].max()
        df_combined = df_combined[df_combined["Week Start"] <= max_week_start]

        return df_combined, min_date_current_year, max_week_start

    except Exception as e:
        logger.error("Error in extract_week_data: ", e)
        raise e

        
def get_aligned_week_start(df_combined: pd.DataFrame, current_year: int, min_date_current_year: pd.Timestamp, max_week_start: pd.Timestamp) -> pd.DataFrame:
    """
    Calculate Aligned Week Start values by mapping week start dates of the current year to all years in df_combined.
    Returns the DataFrame with Aligned Week Start values.
    """
    try:
        current_year_week_starts = df_combined[
            (df_combined['Year'] == current_year) & 
            (df_combined["Date"] > min_date_current_year) & 
            (df_combined["Week Start"] <= max_week_start)
        ][['Week Number', 'Week Start']].drop_duplicates()

        # Set 'Week Number' as the index for mapping
        current_year_week_starts.set_index('Week Number', inplace=True)

        # Map the week start dates of the current year to all years
        df_combined['Aligned Week Start'] = df_combined['Week Number'].map(current_year_week_starts['Week Start'])
        
        return df_combined

    except Exception as e:
        logger.error("Error in get_aligned_week_start: ", e)
        raise e

        
def calculate_growth_and_seasonality(df_pivot: pd.DataFrame, current_year: int, previous_years: list) -> pd.DataFrame:
    """
    Calculate growth percentages and seasonal index.
    Returns the DataFrame with calculated growth percentages and seasonal index.
    """
    
    try:
        # Calculate growth percentages for the last year and forecasted growth for the current year
        df_pivot[f"{previous_years[-1]} Growth% (A)"] = df_pivot[("Actual", previous_years[-1])] / df_pivot[("Actual", previous_years[-2])] * 100
        df_pivot[f"{current_year} Growth% (F)"] = df_pivot[("Forecast", current_year)] / df_pivot[("Actual", previous_years[-1])] * 100

        # Calculate Seasonal Index based on actual values from the past three years
        seasonal_index = 0

        for year in previous_years:
            if ("Actual", year) in df_pivot.columns:
                seasonal_index += df_pivot[("Actual", year)]

        df_pivot[f"Seasonal Index {current_year}"] = seasonal_index
        df_pivot[f"Seasonal Index {current_year}"] /= df_pivot[f"Seasonal Index {current_year}"].mean()

        return df_pivot

    except Exception as e:
        logger.error("Error in calculate_growth_and_seasonality: ", e)
        raise e

        
def calculate_mape(df_pivot: pd.DataFrame, current_year: int) -> pd.DataFrame:
    """
    Calculate the Mean Absolute Percentage Error (MAPE) for each year.
    Returns the DataFrame with calculated MAPE for each year.
    """
    try:
        # Calculate MAPE for each year
        if f"{current_year} Actual" not in df_pivot.columns:
            df_pivot[f"{current_year} Actual"] = np.nan
        actual = df_pivot[f"{current_year} Actual"]
        forecast = df_pivot[f"{current_year} Forecast"]

        # Only include instances where both actual and forecast are not NaN
        not_nan_mask = ~np.isnan(actual) & ~np.isnan(forecast)

        if any(not_nan_mask):
            mape = np.abs((actual[not_nan_mask] - forecast[not_nan_mask]) / actual[not_nan_mask]) * 100
            df_pivot.loc[not_nan_mask, f"{current_year} Absolute Percentage Error"] = mape

        return df_pivot

    except Exception as e:
        logger.error("Error in calculate_mape: ", e)
        raise e

        
def calculate_total_row(df_pivot: pd.DataFrame, current_year: int, previous_years: list) -> pd.DataFrame:
    """
    Calculate the total row in DataFrame.
    Returns the DataFrame with calculated total row.
    """
    try:
        df_pivot.loc["Total"] = df_pivot.sum()

        df_pivot.loc["Total", f"{previous_years[-1]} Growth% (A)"] = df_pivot.loc["Total", f"{previous_years[-1]} Actual"] / df_pivot.loc["Total", f"{previous_years[-2]} Actual"] * 100
        df_pivot.loc["Total", f"{current_year} Growth% (F)"] = df_pivot.loc["Total", f"{current_year} Forecast"] / df_pivot.loc["Total", f"{previous_years[-1]} Actual"] * 100

        return df_pivot

    except Exception as e:
        logger.error("Error in calculate_total_row: ", e)
        raise e

        
def calculate_analysis_table(df_combined: pd.DataFrame, current_year: int, freq_type: str="Month", agg_operation: str="sum") -> pd.DataFrame:
    """
    Calculate a pivot table with various metrics such as actual values, forecast values, growth percentages,
    estimated distribution, seasonal index, and Mean Absolute Percentage Error (MAPE) for the current year
    and the previous three years.
    """
    try:
        # Filter the dataframe to include only the current and the previous three years
        previous_years = [y for y in df_combined['Year'].unique() if y < current_year]
        df_filtered = df_combined[df_combined["Year"].isin(previous_years + [current_year])]

        # Pivot the DataFrame to compare actual and forecast values
        df_filtered["Forecast"] = df_filtered["Forecast"].fillna(0)
        df_pivot = pd.pivot_table(df_filtered, index=freq_type, columns="Year", values=["Actual", "Forecast", "Lower Forecast", "Upper Forecast"], aggfunc=agg_operation)
        
        # Reorder the rows based on the predefined month order if freq_type is "month"
        if freq_type.lower() == "month":
            df_pivot = df_pivot.reindex(MONTH_ORDER)

        # Calculate growth percentages, seasonal index, and estimated distribution if actual values for the last year are present
        if f"Actual {previous_years[-1]}" in df_pivot.columns.map(lambda x: ' '.join(map(str, x))):
            df_pivot = calculate_growth_and_seasonality(df_pivot, current_year, previous_years)

        df_pivot[f"{current_year} Estimated Distribution (F)"] = df_pivot[("Forecast", current_year)] / df_pivot[("Forecast", current_year)].sum() * 100

        # Convert multi-level columns to a single level
        df_pivot.columns = df_pivot.columns.map(lambda x: ' '.join(map(str, reversed(x))))
        df_pivot.columns = [c.strip() for c in df_pivot.columns]

        
        drop_cols = [c for c in df_pivot.columns if 'Forecast' in c and int(c[:4]) < int(current_year)]
        df_pivot = df_pivot.drop(drop_cols, axis=1)
        

        # Calculate MAPE for each year
        if f"{current_year} Actual" in df_pivot.columns:
            if (df_pivot[f"{current_year} Actual"].fillna(0) > 0).any():
                df_pivot = calculate_mape(df_pivot, current_year)
            else:
                df_pivot.drop([f"{current_year} Actual"], axis=1, inplace=True)

        # Calculate total row
        df_pivot = calculate_total_row(df_pivot, current_year, previous_years)

        return df_pivot

    except Exception as e:
        logger.error("Error in calculate_analysis_table: ", e)
        raise e


def day_peak_table(selected_year: int, current_year: int, train_end_date: datetime, df_combined: pd.DataFrame) -> tuple:
    """
    Calculate selected start date, generate peak data,
    reorder and filter the data, and get unique days.
    """
    try:
        # Determine the selected start date based on the selected year
        if selected_year > current_year:  
            selected_start_date = datetime.datetime(selected_year, 1, 1)
        elif selected_year == current_year:
            selected_start_date = train_end_date + datetime.timedelta(days=1)
        else:
            logger.error('Forecast range is out of scope!')
            return None, None, 'Forecast range is out of scope!'

        # Calculate peak data
        df_peak = df_combined[df_combined["Year"] == selected_year].groupby(['Month', 'Day']).apply(get_peak_row)
        df_peak = df_peak[['Actual', 'Forecast']]
        df_peak['Actual'].fillna(df_peak['Forecast'], inplace=True)

        # Generate pivot table with peak data
        df_peak_table = pd.pivot_table(df_peak, index='Day', columns='Month', values='Actual')
        df_peak_table = df_peak_table.reindex(WEEKDAY_ORDER)
        df_peak_table = df_peak_table[[m for m in MONTH_ORDER if m in df_peak_table.columns]]
        df_peak_table = df_peak_table.dropna(how='all')

        return df_peak_table, selected_start_date, None

    except Exception as e:
        logger.error(f"Error in day_peak_table: {e}")
        raise e


def compute_mbm_table(df_combined: pd.DataFrame, forecast_years: List[int], current_year: int, agg_operation: str) -> pd.DataFrame:
    """
    Calculate month-by-month metrics.
    """
    try:
        # Initialize the month-by-month table for the current year
        df_mbm = calculate_analysis_table(df_combined.copy(deep=True), current_year, "Month", agg_operation.lower())

        # Append the month-by-month tables for the subsequent forecast years
        for year in forecast_years[1:]:
            df_mbm_next = calculate_analysis_table(df_combined.copy(deep=True), year, "Month", agg_operation.lower())
            new_cols = list(set(df_mbm_next.columns).difference(set(df_mbm.columns)))
            df_mbm = pd.concat([df_mbm, df_mbm_next[new_cols]], axis=1)

        return df_mbm

    except Exception as e:
        logger.error(f"Error in compute_mbm_table: {e}")
        raise e
        
        
def compute_peak_mbm_table(df_combined: pd.DataFrame, forecast_years: List[int], current_year: int) -> pd.DataFrame:
    """
    Calculate peak month-by-month metrics.
    """
    try:
        # Initialize the peak month-by-month table for the current year
        for year in forecast_years:
            df_peak = df_combined.groupby(['Year', 'Month']).apply(get_peak_row).reset_index(drop=True)
        df_mbm_peak = calculate_analysis_table(df_peak, current_year, "Month")

        # Append the peak month-by-month tables for the subsequent forecast years
        for year in forecast_years[1:]:
            df_mbm_peak_next = calculate_analysis_table(df_peak, year, "Month")
            new_cols = list(set(df_mbm_peak_next.columns).difference(set(df_mbm_peak.columns)))
            df_mbm_peak = pd.concat([df_mbm_peak, df_mbm_peak_next[new_cols]], axis=1)  

        return df_mbm_peak

    except Exception as e:
        logger.error(f"Error in compute_peak_mbm_table: {e}")
        raise e


def compute_wbw_table(df_combined: pd.DataFrame, current_year: int, selected_year: int, agg_operation: str) -> pd.DataFrame:
    """
    Calculate week-by-week metrics.
    """
    try:
        # Extract week data and get aligned week start
        df_combined, min_date_current_year, max_week_start = extract_week_data(df_combined, selected_year)
        df_combined = get_aligned_week_start(df_combined, selected_year, min_date_current_year, max_week_start)
        
        # Calculate the analysis table
        df_wbw = calculate_analysis_table(df_combined.copy(deep=True), selected_year, 'Aligned Week Start', agg_operation.lower())
        
        # Add Week Number
        df_wbw = df_wbw.reset_index()
        df_wbw.index += 1
        df_wbw = df_wbw.rename_axis('Week Number')

        return df_wbw

    except Exception as e:
        logger.error(f"Error in compute_wbw_table: {e}")
        raise e

        
__all__ = ['day_peak_table', 'compute_mbm_table', 'compute_peak_mbm_table', 'compute_wbw_table']