import pandas as pd
import numpy as np
import datetime
from typing import Optional, Tuple, List, Dict, Any
import plotly.graph_objs as go
import logging

# Logger setup
logger = logging.getLogger(__name__)


WEEKDAY_ORDER = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
MONTH_ORDER = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]


def wbw_plot(df_plot: pd.DataFrame, forecast_start_date: datetime.date, selected_years: List[str], selected_year: int) -> go.Figure:
    """
    Generates a plot with weekly values for selected years, differentiating between actual and forecast data.
    """
    # Transpose dataframe for easier plotting
    aligned_week_starts = df_plot["Aligned Week Start"].tolist()
    
    df_plot_actual = df_plot[[col for col in df_plot.columns if "Actual" in col]].T
    df_plot_actual.drop(df_plot_actual.columns[-1], axis=1, inplace=True)
    
    df_plot_forecast = df_plot[[col for col in df_plot.columns if "Forecast" in col]]
    df_plot_forecast = df_plot_forecast[[col for col in df_plot_forecast.columns if "Lower" not in col and "Upper" not in col]].T
    df_plot_forecast.drop(df_plot_forecast.columns[-1], axis=1, inplace=True)

    # Set up figure and color palette
    fig = go.Figure()
    fig.update_layout(autosize=False, width=1000, height=500)
    colors = ['steelblue', 'coral', 'deeppink', 'slategray', 'salmon', 'crimson', 'darkcyan']
    
    # Add a line for each year in selected_years, differentiate actual vs. forecast with color and line style
    for idx, year in enumerate(selected_years):
        
        year_int = int(year)
        year = f"{year_int} Actual"
        
        if year_int == forecast_start_date.year:
            actual_weeks = df_plot_actual.columns[df_plot_actual.columns < forecast_start_date.isocalendar()[1]]
            forecasted_weeks = df_plot_actual.columns[df_plot_actual.columns >= forecast_start_date.isocalendar()[1]]

            # Actual data
            fig.add_trace(
                go.Scatter(x=actual_weeks, y=df_plot_actual.loc[year, actual_weeks], mode='lines+markers',
                           name=str(year), line=dict(color='green'))
            )
            if year_int == int(selected_year):
                # Forecast data
                year = year.replace("Actual", "Forecast")
                fig.add_trace(
                    go.Scatter(x=forecasted_weeks, y=df_plot_forecast.loc[year, forecasted_weeks], mode='lines+markers',
                               name=str(year).replace("Actual", "Forecast"), line=dict(dash='dot', color='seagreen'))
            )
            else:
                # Forecast data
                fig.add_trace(
                    go.Scatter(x=forecasted_weeks, y=df_plot_actual.loc[year, forecasted_weeks], mode='lines+markers',
                               name=str(year).replace("Actual", "Forecast"), line=dict(dash='dot', color='mediumseagreen'))
            )
            
        elif year_int == forecast_start_date.year + 1:
            # Forecast for next year
            forecasted_weeks = df_plot_forecast.columns
            year = year.replace("Actual", "Forecast")
            fig.add_trace(
                go.Scatter(x=forecasted_weeks, y=df_plot_forecast.loc[year, forecasted_weeks], mode='lines+markers',
                           name=str(year), line=dict(dash='dot', color='mediumseagreen'))
            )
        elif year_int >= forecast_start_date.year + 2:
            # Forecast for 2+ years in future
            forecasted_weeks = df_plot_forecast.columns
            year = year.replace("Actual", "Forecast")
            fig.add_trace(
                go.Scatter(x=forecasted_weeks, y=df_plot_forecast.loc[year, forecasted_weeks], mode='lines+markers',
                           name=str(year), line=dict(dash='dot', color='lightseagreen'))
            )
        else:
            # Actual data for years before forecast_start_year
            fig.add_trace(
                go.Scatter(x=df_plot_actual.columns, y=df_plot_actual.loc[year], mode='lines+markers',
                           name=str(year), line=dict(color=colors[idx % len(colors)])
                )
            )

    # Customize plot title and x-axis ticks
    fig.update_layout(title='Weekly Values')
    fig.update_layout(
        xaxis=dict(
            tickmode='array',
            tickvals=list(range(1, len(aligned_week_starts))),
            ticktext=[str(s).split(" ")[0] for s in aligned_week_starts],
        )
    )

    return fig


def mbm_plot(df_plot: pd.DataFrame, forecast_start_date: datetime.date, selected_years: List[str]) -> go.Figure:
    """
    Generates a plot with monthly values for selected years, differentiating between actual and forecast data.
    """

    # Transpose dataframe for easier plotting
    df_plot_actual = df_plot[[col for col in df_plot.columns if "Actual" in col]].T
    df_plot_actual.drop(df_plot_actual.columns[-1], axis=1, inplace=True)

    
    df_plot_forecast = df_plot[[col for col in df_plot.columns if "Forecast" in col]]
    df_plot_forecast = df_plot_forecast[[col for col in df_plot_forecast.columns if "Lower" not in col and "Upper" not in col]].T
    df_plot_forecast.drop(df_plot_forecast.columns[-1], axis=1, inplace=True)

    # Set up figure and color palette
    fig = go.Figure()
    fig.update_layout(autosize=False, width=1000, height=500)
    colors = ['steelblue', 'coral', 'deeppink', 'slategray', 'salmon', 'crimson', 'darkcyan']

    # Add a line for each year in selected_years, differentiate actual vs. forecast with color and line style
    for idx, year in enumerate(selected_years):
        year_int = int(year)
        year = f"{year_int} Actual"
        if year_int == forecast_start_date.year:

            actual_months = df_plot_actual.columns[df_plot_actual.columns.isin(MONTH_ORDER[:forecast_start_date.month])]
            forecasted_months = df_plot_actual.columns[df_plot_actual.columns.isin(MONTH_ORDER[forecast_start_date.month:])]
            
            # Actual data
            fig.add_trace(
                go.Scatter(x=actual_months, y=df_plot_actual.loc[year, actual_months], mode='lines+markers',
                           name=str(year), line=dict(color='green'))
            )
            
            # Forecast data
            year = year.replace("Actual", "Forecast")
            fig.add_trace(
                go.Scatter(x=forecasted_months, y=df_plot_forecast.loc[year, forecasted_months], mode='lines+markers',
                           name=str(year), line=dict(dash='dot', color='darkseagreen'))
            )
        elif year_int == forecast_start_date.year + 1:
            # Forecast for next year
            year = year.replace("Actual", "Forecast")
            forecasted_months = df_plot_forecast.columns[df_plot_forecast.columns.isin(MONTH_ORDER)]
            fig.add_trace(
                go.Scatter(x=forecasted_months, y=df_plot_forecast.loc[year, forecasted_months], mode='lines+markers',
                           name=str(year), line=dict(dash='dot', color='mediumseagreen'))
            )
        elif year_int >= forecast_start_date.year + 2:
            # Forecast for 2+ years in future
            forecasted_months = df_plot_forecast.columns[df_plot.columns.isin(MONTH_ORDER)]
            year = year.replace("Actual", "Forecast")
            fig.add_trace(
                go.Scatter(x=forecasted_months, y=df_plot_forecast.loc[year, forecasted_months], mode='lines+markers',
                           name=str(year), line=dict(dash='dot', color='lightseagreen'))
            )
        else:
            # Actual data for years before forecast_start_year
            fig.add_trace(
                go.Scatter(x=df_plot_actual.columns, y=df_plot_actual.loc[year], mode='lines+markers',
                           name=str(year), line=dict(color=colors[idx % len(colors)])
                )
            )

    # Customize plot title
    fig.update_layout(title='Monthly Values')

    return fig


def pdm_plot(df_peak_table: pd.DataFrame, forecast_start_date: datetime.date, unique_days: List[str]) -> go.Figure:
    """
    Generates a plot with peak day values for unique days, differentiating between actual and forecast data.
    """
    
    # Extract month names present in the dataframe's columns
    month_names = [m for m in MONTH_ORDER if m in df_peak_table.columns]
    
    # Map each weekday to a specific color for plotting
    day_to_color = {
        'Monday': 'steelblue',
        'Tuesday': 'slategray',
        'Wednesday': 'coral',
        'Thursday': 'green',
        'Friday': 'pink',
        'Saturday': 'salmon',
        'Sunday': 'seagreen'
    }
    
    # Create an empty plotly Figure
    fig = go.Figure()
    fig.update_layout(autosize=False, width=1000, height=500)

    # Plot each unique day, split into actual and forecasted data at the forecast_start_date
    for day in unique_days:
        actual_months = month_names[:forecast_start_date.month]
        forecasted_months = month_names[forecast_start_date.month - 1:]
        
        # Actual data
        fig.add_trace(
            go.Scatter(
                x=actual_months, 
                y=df_peak_table.loc[day, actual_months], 
                mode='lines+markers',
                name=f"{day} Actual",
                line=dict(color=day_to_color[day])
            )
        )

        # Forecast data
        fig.add_trace(
            go.Scatter(
                x=forecasted_months, 
                y=df_peak_table.loc[day, forecasted_months], 
                mode='lines+markers',
                name=f"{day} Forecast",
                line=dict(dash='dot', color=f"light{day_to_color[day]}")
            )
        )

    # Customize plot title
    fig.update_layout(title='Peak Day Values')

    return fig


__all__ = ['wbw_plot', 'mbm_plot', 'pdm_plot']